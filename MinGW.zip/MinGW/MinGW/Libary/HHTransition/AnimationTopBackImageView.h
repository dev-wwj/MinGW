//
//  AnimationImageView.h
//  当当
//
//  Created by 豫风 on 2019/7/17.
//  Copyright © 2019 DangDang. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface AnimationTopBackImageView : UIImageView

@end

NS_ASSUME_NONNULL_END
