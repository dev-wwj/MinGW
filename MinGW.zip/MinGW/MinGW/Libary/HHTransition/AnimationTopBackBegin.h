//
//  AnimationTopBackBegin.h
//  HHTransitionDemo
//
//  Created by 豫风 on 2019/7/17.
//  Copyright © 2019 豫风. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface AnimationTopBackBegin : NSObject<UIViewControllerAnimatedTransitioning>

@end

NS_ASSUME_NONNULL_END
