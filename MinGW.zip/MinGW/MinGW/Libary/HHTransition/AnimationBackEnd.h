//
//  AnimationBackEnd.h
//  https://github.com/yuwind/HHTransition
//
//  Created by 豫风 on 2018/4/23.
//  Copyright © 2018年 豫风. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AnimationBackEnd : NSObject<UIViewControllerAnimatedTransitioning>

@end
