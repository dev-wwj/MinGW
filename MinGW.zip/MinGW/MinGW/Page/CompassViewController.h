//
//  CompassViewController.h
//  MinGW
//
//  Created by wangwenjian on 2022/11/11.
//

#import "BaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface CompassViewController : BaseViewController

@end

NS_ASSUME_NONNULL_END
