//
//  CustomNaviViewController.h
//  NativeEastNews
//
//  Created by admin on 15/10/8.
//  Copyright © 2015年 Gaoxin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomNaviViewController : UINavigationController

@property (nonatomic , assign) UIInterfaceOrientation interfaceOrientation;
@property (nonatomic , assign) UIInterfaceOrientationMask interfaceOrientationMask;

@end
