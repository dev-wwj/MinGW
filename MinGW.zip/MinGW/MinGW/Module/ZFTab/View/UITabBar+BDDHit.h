//
//  UITabBar+BDDHit.h
//  步多多
//
//  Created by Chenyoh on 2022/1/21.
//  Copyright © 2022 songheng. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UITabBar (BDDHit)

@end

NS_ASSUME_NONNULL_END
