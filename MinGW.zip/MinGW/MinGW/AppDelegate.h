//
//  AppDelegate.h
//  MinGW
//
//  Created by wangwenjian on 2022/11/11.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (nonatomic , strong) UIWindow *window;

@end

